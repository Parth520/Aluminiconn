window._config = {
    cognito: {
        userPoolId: 'us-east-1_vhqIQjmz7', // e.g. us-east-2_uXboG5pAb
        region: 'us-east-1', // e.g. us-east-2
		clientId: '2aigl6dh7mo1drgddt5spkjf3q' //is this used anywhere?
    },
};

